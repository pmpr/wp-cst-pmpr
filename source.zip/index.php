<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56bfdb512             |
    |_______________________________________|
*/
 use Pmpr\Custom\Pmpr\Pmpr; Pmpr::symcgieuakksimmu();
