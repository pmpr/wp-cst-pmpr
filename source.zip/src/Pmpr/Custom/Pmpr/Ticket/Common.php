<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587953a5ad             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Ticket; use Pmpr\Custom\Pmpr\Container; abstract class Common extends Container { }
