<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a425d97a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Ticket; use Pmpr\Custom\Pmpr\Container; abstract class Common extends Container { }
