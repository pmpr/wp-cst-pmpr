<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587953a5ad             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\141\x64\166\x61\156\143\145\x64\55\x63\x6d\x73"))) { goto wsesqmcqoiyyqkqi; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\162\x65\147\x69\163\164\x65\162\137\163\150\x6f\x72\x74\143\x6f\144\x65\163", [$this, "\x72\145\147\x69\x73\164\x65\162"]); wsesqmcqoiyyqkqi: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
