<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116183690             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\141\144\x76\x61\156\143\145\144\x2d\143\155\x73"))) { goto eogwckcymuugikuy; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\x72\145\147\151\x73\164\145\x72\x5f\x73\150\157\162\x74\143\157\x64\145\x73", [$this, "\162\145\147\x69\163\164\145\162"]); eogwckcymuugikuy: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
