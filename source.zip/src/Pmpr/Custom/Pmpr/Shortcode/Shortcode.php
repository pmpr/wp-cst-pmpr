<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a425d97a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if ($wksoawcgagcgoask = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->gsaceacmqiuqoouo('advanced-cms', Constants::wcwmcocqaeiwwuss)) { $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}_register_shortcodes", [$this, 'register']); } } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
