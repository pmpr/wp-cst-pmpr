<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1f132e23a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\166\141\x6e\x63\145\144\x2d\x63\155\163"))) { goto mggeqkcksyaymcsa; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\x72\145\x67\151\x73\164\x65\162\x5f\163\150\157\162\x74\143\157\x64\145\x73", [$this, "\x72\x65\x67\x69\163\x74\145\x72"]); mggeqkcksyaymcsa: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
