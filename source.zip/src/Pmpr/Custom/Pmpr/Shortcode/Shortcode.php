<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b05f67c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\141\x64\x76\141\156\143\145\x64\x2d\x63\155\163"))) { goto iomcaiwewsawiamu; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\x72\x65\147\151\x73\164\145\162\137\x73\150\157\x72\x74\143\x6f\x64\145\x73", [$this, "\x72\x65\x67\151\x73\164\145\162"]); iomcaiwewsawiamu: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
