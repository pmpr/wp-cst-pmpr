<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661d98ee86d90             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\x76\x61\156\x63\145\x64\55\143\155\163"))) { goto mggeqkcksyaymcsa; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\x72\145\147\151\x73\x74\x65\162\x5f\163\x68\x6f\162\164\143\157\x64\x65\x73", [$this, "\162\145\x67\151\x73\164\145\162"]); mggeqkcksyaymcsa: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
