<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8b2b8f5a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\x76\x61\x6e\143\145\144\x2d\x63\x6d\x73"))) { goto iesekaeqeomeuaui; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\162\145\147\x69\163\x74\x65\162\x5f\x73\150\x6f\x72\x74\143\157\x64\145\x73", [$this, "\162\x65\147\x69\x73\x74\145\162"]); iesekaeqeomeuaui: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
