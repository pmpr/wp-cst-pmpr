<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66302eef91576             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\141\144\166\141\x6e\143\145\144\55\x63\155\163"))) { goto mogkoocsoeuyoqqa; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\x72\145\x67\151\x73\x74\145\x72\x5f\163\x68\x6f\162\164\x63\x6f\x64\145\x73", [$this, "\x72\x65\x67\151\x73\x74\x65\162"]); mogkoocsoeuyoqqa: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
