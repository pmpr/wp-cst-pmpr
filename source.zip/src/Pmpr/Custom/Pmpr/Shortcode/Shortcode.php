<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707e30fd87             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\166\x61\x6e\x63\x65\144\x2d\x63\155\163"))) { goto iomcaiwewsawiamu; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\x72\145\147\151\x73\x74\145\x72\137\163\150\x6f\x72\164\143\x6f\144\x65\x73", [$this, "\162\145\147\151\163\x74\x65\x72"]); iomcaiwewsawiamu: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
