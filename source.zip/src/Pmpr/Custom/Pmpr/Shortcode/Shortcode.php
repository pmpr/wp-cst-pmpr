<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d562b678e1             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\141\x64\166\141\x6e\x63\145\x64\x2d\143\155\x73"))) { goto qgegkeomwscwwiuw; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\x72\145\x67\151\163\x74\145\162\137\x73\150\157\162\x74\x63\157\144\145\163", [$this, "\x72\x65\x67\x69\x73\164\x65\162"]); qgegkeomwscwwiuw: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
