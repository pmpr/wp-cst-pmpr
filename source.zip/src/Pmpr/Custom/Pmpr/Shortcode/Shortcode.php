<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a853c4d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\166\x61\156\x63\x65\x64\55\x63\x6d\x73"))) { goto foeeqckqsyockkak; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\162\x65\147\151\163\x74\x65\x72\137\x73\x68\157\x72\164\x63\157\144\145\163", [$this, "\x72\x65\147\151\163\x74\x65\162"]); foeeqckqsyockkak: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
