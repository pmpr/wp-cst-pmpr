<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf78fc57b0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\x64\x76\141\x6e\x63\x65\144\x2d\143\x6d\163"))) { goto mogkoocsoeuyoqqa; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\162\x65\x67\151\x73\x74\x65\162\137\x73\x68\157\162\x74\143\x6f\144\x65\163", [$this, "\x72\145\x67\x69\x73\164\x65\162"]); mogkoocsoeuyoqqa: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
