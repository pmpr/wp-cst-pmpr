<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6688fb3582f9d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\x76\x61\x6e\143\x65\144\55\x63\x6d\x73"))) { goto iomcaiwewsawiamu; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\162\x65\147\151\x73\164\x65\162\137\163\150\157\162\164\x63\x6f\144\x65\163", [$this, "\162\x65\147\151\163\164\145\162"]); iomcaiwewsawiamu: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
