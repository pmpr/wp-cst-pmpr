<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cee1648d953             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\x64\x76\141\x6e\143\x65\144\55\x63\155\x73"))) { goto eogwckcymuugikuy; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\x72\145\147\x69\163\x74\145\162\137\163\150\157\x72\x74\x63\x6f\x64\145\x73", [$this, "\x72\x65\x67\x69\163\x74\x65\x72"]); eogwckcymuugikuy: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
