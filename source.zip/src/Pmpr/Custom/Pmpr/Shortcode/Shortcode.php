<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634d53c3f1d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\166\141\x6e\143\x65\x64\x2d\x63\x6d\x73"))) { goto mogkoocsoeuyoqqa; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\x72\x65\x67\151\163\x74\x65\x72\137\x73\150\157\162\x74\143\157\144\x65\x73", [$this, "\x72\x65\147\x69\x73\164\145\x72"]); mogkoocsoeuyoqqa: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
