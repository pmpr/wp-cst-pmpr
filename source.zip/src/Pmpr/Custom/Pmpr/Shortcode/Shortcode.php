<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f43ede086             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\141\x64\x76\x61\156\x63\145\144\55\x63\x6d\x73"))) { goto goacqqsgaaigyuaw; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\162\145\147\x69\x73\x74\145\162\x5f\x73\150\x6f\x72\x74\x63\157\144\145\163", [$this, "\x72\145\147\151\163\164\145\162"]); goacqqsgaaigyuaw: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
