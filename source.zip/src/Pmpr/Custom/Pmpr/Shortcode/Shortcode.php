<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebb0b4d50             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\x64\166\x61\156\x63\145\144\x2d\143\x6d\163"))) { goto qgegkeomwscwwiuw; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\162\x65\x67\x69\163\x74\x65\162\137\x73\x68\157\x72\x74\x63\157\x64\145\x73", [$this, "\162\x65\x67\x69\163\x74\x65\x72"]); qgegkeomwscwwiuw: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
