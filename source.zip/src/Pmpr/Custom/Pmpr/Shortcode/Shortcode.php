<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec344882f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\141\x64\166\x61\x6e\x63\145\144\55\143\155\x73"))) { goto iesekaeqeomeuaui; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\x72\145\x67\x69\x73\164\145\x72\x5f\x73\x68\157\162\x74\143\157\144\x65\163", [$this, "\162\x65\x67\151\x73\164\x65\x72"]); iesekaeqeomeuaui: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
