<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada6f1b144             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\x64\x76\141\156\143\x65\144\55\x63\155\x73"))) { goto qgegkeomwscwwiuw; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\162\x65\147\151\163\x74\x65\162\x5f\163\x68\157\x72\164\143\x6f\144\145\163", [$this, "\x72\x65\x67\151\x73\164\x65\162"]); qgegkeomwscwwiuw: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
