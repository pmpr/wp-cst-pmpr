<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56bfdb512             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Woocommerce; use Pmpr\Custom\Pmpr\Container; class Common extends Container { public function aqasygcsqysmmyke() : int { $product = $this->caokeucsksukesyo()->giiecckwoyiawoyy()->ayueggmoqeeukqmq(self::kqigmeickowqiiyy); if ($product) { goto sqiciiuwmykocycc; } $product = $this->caokeucsksukesyo()->aqasygcsqysmmyke()->iooowgsqoyqseyuu(); sqiciiuwmykocycc: return absint($product); } }
