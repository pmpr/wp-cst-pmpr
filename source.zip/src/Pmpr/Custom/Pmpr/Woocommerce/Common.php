<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf78fc57b0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Woocommerce; use Pmpr\Custom\Pmpr\Container; class Common extends Container { public function aqasygcsqysmmyke() : int { $product = $this->caokeucsksukesyo()->giiecckwoyiawoyy()->ayueggmoqeeukqmq(self::kqigmeickowqiiyy); if ($product) { goto goeoymmqqqeeoime; } $product = $this->caokeucsksukesyo()->aqasygcsqysmmyke()->iooowgsqoyqseyuu(); goeoymmqqqeeoime: return absint($product); } }
