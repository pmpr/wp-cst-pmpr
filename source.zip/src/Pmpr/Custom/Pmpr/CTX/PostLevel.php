<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71db19672             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Common\Foundation\Data\Metadata; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class PostLevel extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("metadata_update_{$this->miwqiiqeegeqcwis()}", [$this, 'gsqosgmykwgcqgyc']); parent::kgquecmsgcouyaya(); } public function mgoeqkosywwaoqyw() { parent::mgoeqkosywwaoqyw(); $this->oyeskqayoscwciem()->ickqomquaqgqywkw(true)->eosmogyiwwkyqyek(false)->kukswgcoysaeescm(Constants::mswoacegomcucaik)->ckwgqocyuaysggma(Constants::ouywiegeiyuaaawo, 'post-level')->muuwuqssqkaieqge(__('Post Levels', PR__CST__PMPR))->guiaswksukmgageq(__('Post Level', PR__CST__PMPR))->gucwmccyimoagwcm(__('level for posts', PR__CST__PMPR)); } public static function gsqosgmykwgcqgyc($ugugimquukqwogge) { if ($ugugimquukqwogge instanceof Metadata) { $ugugimquukqwogge->jyumyyugiwwiqomk(45)->saemoowcasogykak(IconInterface::cgaumaacsaeauwqy); } return $ugugimquukqwogge; } }
