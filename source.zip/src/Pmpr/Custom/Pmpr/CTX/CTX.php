<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebb0b4d50             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\x61\x78\x6f\x6e\x6f\x6d\171\x5f\163\x69\156\x67\154\145\137\x76\141\154\x75\145\137\155\x6f\144\151\146\x79\137\x69\x74\x65\155\163", [$this, "\163\143\x6f\x61\x79\x61\x6d\x75\x79\161\147\153\x63\141\155\147"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
