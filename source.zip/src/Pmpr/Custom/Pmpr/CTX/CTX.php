<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f43ede086             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\141\x78\x6f\156\157\155\171\137\x73\151\x6e\x67\154\145\x5f\166\x61\154\x75\145\137\155\157\144\151\146\171\137\151\164\145\155\x73", [$this, "\163\143\157\141\171\x61\155\x75\171\161\x67\153\x63\141\155\x67"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
