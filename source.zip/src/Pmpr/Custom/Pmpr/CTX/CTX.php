<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cc82fd7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\141\x78\x6f\156\x6f\x6d\171\x5f\163\x69\x6e\x67\x6c\145\137\x76\141\154\x75\x65\137\155\x6f\x64\x69\146\171\137\151\x74\x65\x6d\163", [$this, "\x73\143\157\141\x79\x61\155\x75\171\x71\147\x6b\x63\141\x6d\x67"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
