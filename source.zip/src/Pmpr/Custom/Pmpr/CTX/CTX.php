<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634d53c3f1d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\x61\x78\x6f\156\x6f\155\171\x5f\163\151\x6e\x67\x6c\145\137\166\x61\154\165\145\x5f\x6d\x6f\x64\151\146\171\137\151\164\145\x6d\x73", [$this, "\163\143\x6f\141\x79\141\155\x75\171\x71\147\x6b\143\x61\155\x67"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
