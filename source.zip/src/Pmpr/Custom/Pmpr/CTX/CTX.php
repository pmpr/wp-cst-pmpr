<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56bfdb512             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\x61\170\157\x6e\157\155\x79\x5f\x73\151\x6e\147\x6c\x65\137\x76\x61\x6c\165\145\x5f\155\157\x64\x69\x66\x79\x5f\151\164\x65\155\163", [$this, "\163\143\157\x61\171\x61\x6d\x75\171\161\x67\153\143\141\x6d\147"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
