<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d4b6266b3             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom('taxonomy_single_value_modify_items', [$this, 'scoayamuyqgkcamg']); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
