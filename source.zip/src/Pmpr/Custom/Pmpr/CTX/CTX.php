<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b05f67c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\141\170\157\x6e\x6f\155\171\137\x73\x69\x6e\x67\x6c\x65\x5f\166\141\154\x75\x65\x5f\155\x6f\144\151\146\x79\x5f\x69\164\145\x6d\x73", [$this, "\x73\x63\157\141\x79\x61\x6d\165\171\161\x67\x6b\143\141\155\x67"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
