<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661d98ee86d90             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\141\170\x6f\x6e\157\155\x79\x5f\163\x69\x6e\147\x6c\145\137\x76\x61\154\x75\145\137\x6d\x6f\144\151\x66\171\137\x69\164\145\155\x73", [$this, "\x73\143\157\141\x79\141\x6d\x75\171\161\x67\153\143\141\155\147"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
