<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a853c4d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\141\x78\x6f\156\x6f\155\171\137\163\151\x6e\x67\154\145\137\166\141\x6c\165\145\x5f\x6d\157\144\151\x66\x79\137\x69\x74\x65\x6d\163", [$this, "\163\x63\157\x61\171\x61\155\165\171\161\x67\153\143\x61\x6d\147"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
