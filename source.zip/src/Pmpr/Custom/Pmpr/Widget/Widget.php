<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf78fc57b0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Widget; use Pmpr\Custom\Pmpr\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Badge::symcgieuakksimmu(); } }
