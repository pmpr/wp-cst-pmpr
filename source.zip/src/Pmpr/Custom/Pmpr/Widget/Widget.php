<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b05f67c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Widget; use Pmpr\Custom\Pmpr\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Badge::symcgieuakksimmu(); } }
