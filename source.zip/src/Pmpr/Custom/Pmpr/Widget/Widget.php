<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a853c4d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Widget; use Pmpr\Custom\Pmpr\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Badge::symcgieuakksimmu(); } }
