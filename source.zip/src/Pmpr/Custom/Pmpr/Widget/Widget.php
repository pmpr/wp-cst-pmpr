<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634d53c3f1d0             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Widget; use Pmpr\Custom\Pmpr\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Badge::symcgieuakksimmu(); } }
