<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada6f1b144             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
